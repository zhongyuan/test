<?php

/**
 * @执行数据导入的使用示例
 * $obj = new ImportXml(数据库主机,用户名,密码,数据库名称);
 * $obj->doImport();
 * 
 * @特别注意:本程序包括的数据包文件有(所有文件均在同一目录下,防止文件引入失败导致程序出错!) 
 * 1.xml2Array.class.php
 * 2.importXml.class.php
 * 3._toc_Getting Started With COS.xml
 * 4._toc_COS Cplusplus Development.xml
 * 5._toc_COS Web Development.xml 
 */
//header('Content-type:text/html;charset=UTF-8');
include(dirname(__FILE__).'/xml2Array.class.php');

class ImportXml {
	
	private $_host = NULL;
	private $_user = NULL;
	private $_passwd = NULL;
	private $_db = NULL;
	private $_link = NULL;
	
	function __construct($host,$user,$passwd,$db) {
		$this->_host = $host;
		$this->_user = $user;
		$this->_passwd = $passwd;
		$this->_db = $db;
		$this->_connDb();
	}
	
	/**
	 * 执行数据导入操作 
	 * 
	 */
	function doImport()
	{
		$this->_initClassify();
		$this->_importTraining();
		$this->_importCplusplus();
		$this->_importWeb();
		
		echo "\n数据导入完毕!";
	}
	
	
	/**
	 * 连接数据库 
	 * 
	 */
	private function _connDb()
	{
		$this->_link = mysql_connect($this->_host,$this->_user,$this->_passwd);
		if(!$this->_link){
			echo(mysql_error());
			exit(0);
		}
		mysql_query("SET NAMES 'utf8'");
		$flag = mysql_select_db($this->_db,$this->_link);
		if(!$flag){
			echo("选择数据库失败");
			exit(0);
		}
	}
	
	
	/**
	 * 初始化分类 
	 * 
	 */
	private function _initClassify()
	{
		
		$tb_sql = "CREATE TABLE IF NOT EXISTS `api` (
		  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
		  `name` varchar(100) NOT NULL DEFAULT '0' COMMENT '节点名',
		  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '父节点',
		  `path` varchar(255) NOT NULL DEFAULT '0' COMMENT '存放路径',
		  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-2审核失败，-1待审核，0为删除，1为正常或审核通过',
		  `staff_id` int(11) NOT NULL DEFAULT '0' COMMENT '增加节点的人',
		  `update_time` int(11) NOT NULL DEFAULT '0',
		  `record_time` int(11) NOT NULL DEFAULT '0',
		  PRIMARY KEY (`id`),
		  KEY `parent_id` (`parent_id`)
		) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='cos开发者模块' AUTO_INCREMENT=1 ;";
		mysql_query($tb_sql,$this->_link);
		
		$time = time();
		$sql = "INSERT INTO `api` (`id`, `name`, `parent_id`, `path`, `status`, `staff_id`, `update_time`, `record_time`) VALUES
		(1, 'Traning', 0, 'html/Getting Started With COS.html', 0, 0, 0, 1365991680),
		(2, 'Develop Guides', 0, '/', 0, 0, 0, '$time'),
		(3, 'API Reference', 0, '/', 0, 0, 0, '$time'),
		(4, 'Tools', 0, '/', 0, 0, 0, '$time'),
		(5, 'COS Cplusplus Development', 2, 'html/COS Cplusplus Development.html', 0, 0, 0, '$time'),
		(6, 'COS Web Development', 2, 'html/COS Web Development.html', 0, 0, 0, '$time')";
		mysql_query($sql,$this->_link);
	}
	
	private function _importTraining()
	{
		 $xml = dirname(__FILE__)."/_toc_Getting Started With COS.xml";
		 $data = XML2Array::createArray($xml);
		 $this->_parseTopics($data['toc']['topic']);
	}
	
	private function _importCplusplus()
	{
		$xml = dirname(__FILE__)."/_toc_COS Cplusplus Development.xml";
		$data = XML2Array::createArray($xml);
		$this->_parseTopics($data['toc']['topic'][0]['topic'],5);
	}
	
	private function _importWeb()
	{
		$xml = dirname(__FILE__)."/_toc_COS Web Development.xml";
		$data = XML2Array::createArray($xml);
		$this->_parseTopics($data['toc']['topic']['topic'],6);
	}
	
	private function _parseTopics($data,$parent_id = 1)
	{
		$topics = $data;
		if(isset($topics['@value'])){
			$this->_saveInfo($topics,$parent_id);
		}else{
			if(isset($data['topic']) && is_array($data['topic'])){
				$topics = $data['topic'];
			}
			foreach($topics as $et){
				$last_id = 0;
				//获取基本属性
				$insert_id = $this->_saveInfo($et,$parent_id);
				if($insert_id){
					$last_id = $insert_id;
				}
				//获取子节点内容
				if(isset($et['topic']) && is_array($et['topic'])){
					$this->_parseTopics($et['topic'],$last_id);
				}
			}	
		}
		
	}

	private function _saveInfo($et,$parent_id)
	{
		//获取基本属性
		if(isset($et['@attributes']['href']) && isset($et['@attributes']['label'])){
			
			echo("\n".$et['@attributes']['label']." | ".$et['@attributes']['href']);
			
			//检测是否已存在
			$query = mysql_query("SELECT COUNT(*) as CNT FROM api WHERE path = '".$et['@attributes']['href']."'",$this->_link);
			$cnt = mysql_result($query,0);
			if($cnt>0){
				echo("\nExisted item:".$et['@attributes']['href']);
				return FALSE;
			}
			//追加一条记录
			$sql = "INSERT INTO api(parent_id,name,path,status,record_time) VALUES('$parent_id','".$et['@attributes']['label']."','".$et['@attributes']['href']."','1','".time()."')";
			$flag = mysql_query($sql,$this->_link);
			if(!$flag){
				echo "\nERROR:".$sql;
				return FALSE;
			}
			$last_id = mysql_insert_id();
			return $last_id;
		}
		return FALSE;
	}
}
?>