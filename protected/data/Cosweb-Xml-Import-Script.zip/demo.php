<?php

header('Content-type:text/html;charset=UTF-8');
require_once(dirname(__FILE__)."/importXml.class.php");
$obj = new ImportXml("localhost","root","admin123","cosweb");
$obj->doImport();

?>